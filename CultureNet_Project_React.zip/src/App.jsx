import React from 'react';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import StoryGenerator from './components/StoryGenerator';
import ArtGallery from './components/ArtGallery';
import LiveStream from './components/LiveStream';

function App() {
  return (
    <div className="bg-[#fff5e6] min-h-screen">
      <Navbar />
      <HeroSection />
      <StoryGenerator />
      <ArtGallery />
      <LiveStream />
    </div>
  );
}

export default App;