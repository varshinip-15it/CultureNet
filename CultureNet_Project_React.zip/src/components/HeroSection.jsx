import React from 'react';

const HeroSection = () => (
  <section className="text-center py-16 px-4 bg-gradient-to-r from-orange-200 to-yellow-100">
    <h1 className="text-4xl font-bold text-orange-800 mb-4">CultureNet</h1>
    <p className="text-lg text-orange-700">
      Reviving heritage with the power of AI, edge computing, and 5G connectivity.
    </p>
  </section>
);

export default HeroSection;