import React from 'react';

const LiveStream = () => (
  <div className="p-6">
    <h2 className="text-xl font-semibold text-orange-800">Live Cultural Events</h2>
    <div className="mt-4">
      <iframe
        className="w-full h-64"
        src="https://www.youtube.com/embed/2xG-bGd-MvA"
        title="Live Cultural Event"
        allowFullScreen
      ></iframe>
    </div>
  </div>
);

export default LiveStream;