import React from 'react';

const Navbar = () => <nav className='bg-orange-500 text-white p-4 text-xl'>CultureNet</nav>;

export default Navbar;