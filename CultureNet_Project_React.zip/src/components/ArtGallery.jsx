import React from 'react';

const sampleArt = [
  { title: 'Warli Painting', src: 'https://via.placeholder.com/150' },
  { title: 'Madhubani Art', src: 'https://via.placeholder.com/150' },
];

const ArtGallery = () => (
  <div className="p-6">
    <h2 className="text-xl font-semibold text-orange-800">AI-Generated Cultural Art</h2>
    <div className="grid grid-cols-2 gap-4 mt-4">
      {sampleArt.map((art, idx) => (
        <div key={idx} className="text-center">
          <img src={art.src} alt={art.title} className="rounded shadow" />
          <p className="mt-2 text-orange-700">{art.title}</p>
        </div>
      ))}
    </div>
  </div>
);

export default ArtGallery;