import React, { useState } from 'react';

const StoryGenerator = () => {
  const [input, setInput] = useState('');
  const [story, setStory] = useState('');

  const generateStory = () => {
    setStory(`Long ago in a village of Tamil Nadu, a festival called ${input} brought people together in song, dance, and food.`);
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-semibold mb-2 text-orange-800">AI-Powered Cultural Storytelling</h2>
      <input
        className="border p-2 w-full"
        placeholder="Enter festival or tradition"
        value={input}
        onChange={(e) => setInput(e.target.value)}
      />
      <button onClick={generateStory} className="mt-2 bg-orange-500 text-white px-4 py-2 rounded">
        Generate
      </button>
      {story && <p className="mt-4 text-orange-700">{story}</p>}
    </div>
  );
};

export default StoryGenerator;