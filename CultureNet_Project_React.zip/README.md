# CultureNet – Reviving Heritage with AI & 5G

CultureNet is a web-based app that uses AWS Generative AI and next-gen connectivity to digitally preserve and share cultural stories, art, and experiences.

## Features
- AI-generated cultural storytelling
- AI-enhanced traditional artwork
- Live cultural event streaming
- 5G and IoT-aware content delivery (simulated)

## Technologies
- React.js
- Tailwind CSS
- AWS (mock)
- YouTube Embeds